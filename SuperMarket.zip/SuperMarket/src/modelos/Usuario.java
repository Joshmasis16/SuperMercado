/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

/**
 *
 * @author ovied
 */
public class Usuario {
   private int id;
   private String nombre;
   private String primerApell;
   private String segundoApell;
   private String cedula;
   private String domicilio;
   private String telefono;

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getPrimerApell() {
        return primerApell;
    }

    public String getSegundoApell() {
        return segundoApell;
    }

    public String getCedula() {
        return cedula;
    }

    public String getDomicilio() {
        return domicilio;
    }

    public String getTelefono() {
        return telefono;
    }
   

    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPrimerApell(String primerApell) {
        this.primerApell = primerApell;
    }

    public void setSegundoApell(String segundoApell) {
        this.segundoApell = segundoApell;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
  
}
