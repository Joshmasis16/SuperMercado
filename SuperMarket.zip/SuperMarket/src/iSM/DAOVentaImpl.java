/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package iSM;

import db.Database;
import interfaces.DAOVenta;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import modelos.Producto;
import modelos.Usuario;
import modelos.Venta;

/**
 *
 * @author ovied
 */
public class DAOVentaImpl extends Database implements DAOVenta{
    @Override
    public void registrar(Venta venta){
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("INSERT INTO ventas(usuarioId, productoId) VALUES(?,?);");
            st.setInt(1, venta.getUsuarioId());
            st.setInt(2, venta.getProductoId());
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null, "Error " + e.getMessage());
        } 
    }

    @Override
    public void modificar(Venta venta){
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("UPDATE ventas SET usuarioId = ?, book_id = ? WHERE id = ?");
            st.setInt(1, venta.getUsuarioId());
            st.setInt(2, venta.getProductoId());
            st.setInt(5, venta.getId());
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null, "Error " + e.getMessage());
        } 
    }

    

    @Override
    public List<Venta> listar(){
        List<Venta> lista = null;
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("SELECT * FROM ventas ORDER BY id DESC");
            
            lista = new ArrayList();
            ResultSet rs = st.executeQuery();
            while(rs.next()) {
                Venta venta = new Venta();
                venta.setId(rs.getInt("id"));
                venta.setUsuarioId(rs.getInt("usuarioId"));
                venta.setProductoId(rs.getInt("productoId"));
                lista.add(venta);
            }
            rs.close();
            st.close();
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null, "Error " + e.getMessage());
        } 
        return lista;
    }
    
    @Override
    public Venta getVenta(Usuario usuario, Producto producto)
    {
        Venta venta = null;
        
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("SELECT * FROM ventas WHERE usuarioId = ? AND productoId = ? ORDER BY id DESC LIMIT 1");
            st.setInt(1, usuario.getId());
            st.setString(2, producto.getId());
            
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                venta = new Venta();
                venta.setId(rs.getInt("id"));
                venta.setUsuarioId(rs.getInt("usuarioId"));
                venta.setProductoId(rs.getInt("productoId"));
            }
            
            st.close();
            rs.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error " + e.getMessage());
        } 
        
        return venta;
    }
}
