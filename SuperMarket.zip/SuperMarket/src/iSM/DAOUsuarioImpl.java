/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package iSM;
import db.Database;
import interfaces.DAOUsuario;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import modelos.Usuario;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author ovied
 */
public class DAOUsuarioImpl extends Database implements DAOUsuario{
 
    @Override
    public void registrar(Usuario usuario){
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("INSERT INTO usuarios(nombre, primer_apellido, segundo_apellido, cedula, domicilio, telefono) VALUES(?,?,?,?,?,?);");
            st.setString(1, usuario.getNombre());
            st.setString(2, usuario.getPrimerApell());
            st.setString(3, usuario.getSegundoApell());
            st.setString(4, usuario.getCedula());
            st.setString(5, usuario.getDomicilio());
            st.setString(6, usuario.getTelefono());
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null, "Error " + e.getMessage());
        } 
    }

    @Override
    public void modificar(Usuario usuario){
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("UPDATE usuarios SET nombre = ?, primer_apellido = ?, segundo_apellido= ?, cedula = ? ,domicilio = ?, telefono = ? WHERE id = ?");
            st.setString(1, usuario.getNombre());
            st.setString(2, usuario.getPrimerApell());
            st.setString(3, usuario.getSegundoApell());
            st.setString(4, usuario.getDomicilio());
            st.setString(5, usuario.getCedula());
            st.setString(6, usuario.getTelefono());
            st.setInt(7, usuario.getId());
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null, "Error " + e.getMessage());
        } 
    }

    @Override
    public void eliminar(int usuarioId){
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("DELETE FROM usuarios WHERE id = ?;");
            st.setInt(1, usuarioId);
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null, "Error " + e.getMessage());
        } 
    }

    @Override
    public List<Usuario> listar(String nombre)
    {
        List<Usuario> lista = null;
        try {
            this.Conectar();
            String Query = nombre.isEmpty() ? "SELECT * FROM usuarios;" : "SELECT * FROM usuarios WHERE nombre LIKE '%" + nombre + "%';";
            PreparedStatement st = this.conexion.prepareStatement(Query);
            
            lista = new ArrayList();
            ResultSet rs = st.executeQuery();
            while(rs.next()) {
                Usuario user = new Usuario();
                user.setId(rs.getInt("id"));
                user.setNombre(rs.getString("nombre"));
                user.setPrimerApell(rs.getString("primer_apellido"));
                user.setSegundoApell(rs.getString("segundo_apellido"));
                user.setCedula(rs.getString("cedula"));
                user.setDomicilio(rs.getString("domicilio"));
                user.setTelefono(rs.getString("telefono"));
                lista.add(user);
            }
            rs.close();
            st.close();
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null, "Error " + e.getMessage());
        } 
        return lista;
    }
    
    @Override
    public Usuario obtenerUsuario(int usuarioId)
    {
        Usuario user = null;
        
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("SELECT * FROM usuarios WHERE id = ? LIMIT 1;");
            st.setInt(1, usuarioId);
            
            ResultSet rs = st.executeQuery();
            while(rs.next()) {
                user = new Usuario();
                user.setId(rs.getInt("id"));
                user.setNombre(rs.getString("nombre"));
                user.setPrimerApell(rs.getString("primer_apellido"));
                user.setSegundoApell(rs.getString("segundo_apellido"));
                user.setCedula(rs.getString("cedula"));
                user.setDomicilio(rs.getString("domicilio"));
                user.setTelefono(rs.getString("telefono"));
                
            }
            rs.close();
            st.close();
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null, "Error " + e.getMessage());
        } 
        return user;
    }
    
    
  
}
