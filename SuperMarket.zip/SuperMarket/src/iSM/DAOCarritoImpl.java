/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package iSM;
import db.Database;
import interfaces.DAOCarrito;

/**
 *
 * @author ovied
 */
public class DAOCarritoImpl extends Database implements DAOCarrito{
    
}
