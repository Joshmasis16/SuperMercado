/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interfaces;

import java.util.List;
import modelos.Producto;
import modelos.Usuario;
import modelos.Venta;

/**
 *
 * @author ovied
 */
public interface DAOProducto {
    public void registrar(Producto producto);
    //public void modificar(Producto producto);    
    public void eliminar(String productoId);
    public Producto obtenerLibro(int productoId);
    public List<Producto> listar(String id);
}
