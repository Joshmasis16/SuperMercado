/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interfaces;

import java.util.List;
import modelos.Producto;
import modelos.Usuario;
import modelos.Venta;

/**
 *
 * @author ovied
 */
public interface DAOVenta {
    public void registrar(Venta venta);
    public void modificar(Venta venta);
    public Venta getVenta(Usuario usuario, Producto producto);
    // public void eliminar(Lendings user) throws Exception;
    public List<Venta> listar();
    
}
